package annotation;

public enum ConstraintType {
	REQUIRES, EXCLUDES, NULL
}
