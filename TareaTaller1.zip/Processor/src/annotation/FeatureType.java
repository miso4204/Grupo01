package annotation;

public enum FeatureType {
	ALT, OR, AND, NULL
}
